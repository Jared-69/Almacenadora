import axios from "axios";
const URL = "http://localhost:3008/api/"

export const listTareaApi = async()=>{
    try{
        const {data: {users}} = await axios.get(`${URL}read-users`);
        console.log(users)
        return users;
    }catch(error){
        return error;
    }
};

export const deleteTareaApi = async() =>{
    
}