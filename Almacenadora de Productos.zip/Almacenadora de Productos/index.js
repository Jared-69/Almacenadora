'use strict'

const express = require('express');
const app = express();
const {connection} = require("./src/database/connection");
require('dotenv').config();
const port = process.env.PORT;
const user = require('./src/routes/user.routes');
const todo = require('./src/routes/todolist.routes');
const { userdefault } = require('./userdefault.controller');
const cors = require ('cors');

connection();

app.use(express.urlencoded({extended: false}));

app.use(express.json());

app.use(cors());

app.use('/api', user, todo)

app.listen(port, function(){
    console.log(`The server is connected to the port ${port}`);
});

userdefault();