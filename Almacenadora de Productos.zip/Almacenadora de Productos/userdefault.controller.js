'use strict'

const Usuario = require('./src/models/user.model');
const bcrypt = require('bcrypt');

const userdefault = async() => {
    try{
        const user = new Usuario();
        user.username = 'Grupo',
        user.lastname = 'Informatica',
        user.age = '18'
        user.email = 'grupoinformatica2023@kinal.edu.gt'
        user.password = '123456';
        const userEncontrado = await Usuario.findOne({email: user.email})

        if(userEncontrado) return console.log('El usuario listo');

        //Encriptación de contraseña
        user.password = bcrypt.hashSync(user.password, bcrypt.genSaltSync());

        //Guardar Usuario
        user = await user.save();

        if(!user) return console.log('El usuario no esta listo');
        return console.log('El usuario esta listo')

    }catch(error){
        console.log(error)
    }
}

module.exports = {userdefault};