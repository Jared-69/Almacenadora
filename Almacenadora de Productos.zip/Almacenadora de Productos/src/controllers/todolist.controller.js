'use strict'

const ToDo = require('../models/todolist.model');
const User = require('../models/user.model');

const createToDo = async(req, res) =>{
    const {user, taskName, description, startDate, deadline, taskStatus} = req.body;
    try{
        let tarea = await ToDo.findOne({taskName});

        if(tarea){
            return res.status(400).send({
                message: 'Un usuario tiene la tarea',
                ok: false,
                tarea: tarea
            })
        };

        const userSearch = await User.findById(user);

        if(!userSearch){
            return res.status(400).json({
                message: 'No se encontro el usuario',
                ok: false,
                user: userSearch,
            })
        }

        const newTarea = await ToDo.create({user, taskName, description, startDate, deadline, taskStatus});

        userSearch.ToDoList = newTarea._id;
        await userSearch.save();

        res.status(200).send({
            message: 'Tarea creada correctamente',
            ok: true,
            tarea: newTarea,
        })

    }catch(error){
        console.log(error)
        res.status(500).json({
            ok: false,
            message: 'No se ha creado la tarea',
            error: error,
        })
    }
};

const updateToDo = async(req, res) =>{
    try{
        const {id} = req.params;
        const tarea = await ToDo.findByIdAndUpdate(id, req.body, {new: true});

        if(!tarea){
            return res.status(404).json({
                message: 'Tarea no existente'
            })
        }

        res.json(tarea);
    }catch(error){
        throw new Error("Error al actualizar la tarea" + error);
    }
}

const readToDo = async(req, res) =>{
    try{
        const tarea = await ToDo.find();

        if(!tarea){
            res.status(400).send({message: "No hay Tareas disponibles"});
        }else{
            res.status(200).json({"Tareas encontradas": tarea});
        }
    }catch(error){
        throw new Error(error)
    }
}

const deleteToDo = async(req, res) =>{
    try{
        const tarea = await ToDo.findById(req.params.id);
        if(!tarea){
            return res.status(404).json({
                error: "Curso no existente"
            })
        }

        await User.updateMany(
            {tarea: {$in: [tarea._id]}},
            {$pull: {tarea: tarea._id}}
        )

        await tarea.remove();
        res.json({
            message: "Tarea Eliminada"
        })

    }catch(error){
        console.log(error);
        res.status(500).json({
            message: "NO se pudo eliminar la tarea"
        })
    }
}

module.exports = {  createToDo,
                    updateToDo, 
                    readToDo,
                    deleteToDo};
