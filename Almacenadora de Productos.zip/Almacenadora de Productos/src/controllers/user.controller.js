'use strict'

const user = require('../models/user.model');
const ToDo = require('../models/todolist.model');
const bcrypt = require('bcrypt');
const { generateJWT } = require('../helpers/create-jwt');

//Crear Usuario
const CreateUser = async(req, res) =>{
    const {username, email, password} = req.body;

    try{
        let usuario = await user.findOne({email});

        if(usuario){
            return res.status(400).send({
                message: `Un usuario ya esta usando el correo ${email}`,
                ok: false,
                user: usuario,
            });
        }

        usuario = new user(req.body);

        //Encriptación de password
        const saltos = bcrypt.genSaltSync();
        usuario.password = bcrypt.hashSync(password, saltos);

        //Guardar Usuarios
        usuario =  await usuario.save();

        const token = await generateJWT(usuario.id, usuario.username, usuario.email);
        res.status(200).send({
            message: `Usuario ${usuario.username} creado correctamente`,
            ok: true,
            usuario,
            token: token,
        });

        res.status(200).send({
            message: `Usuario ${username} creado correctamente`,
            ok: true,
            usuario: usuario
        });

    }catch(error){
        console.log(error)
        res.status(500).json({
            ok: false,
            message: `No se puede crear el usuario ${username}`,
            error: error,
        })
    }
};

//Actualizar Usuario
const updateUser = async(req, res) =>{
    try{
        const id = req.params.id;
        const userEdit = {...req.body}
        
        //Encriptar contraseña
        userEdit.password = userEdit.password
        ? bcrypt.hashSync(userEdit.password, bcrypt.genSaltSync())
        : userEdit.password;

        const userComplete = await user.findByIdAndUpdate(id, userEdit, {new: true});
        
        if(userComplete){
            const token = await generateJWT(userComplete.id, userComplete.username, userComplete.email);
            return res 
            .status(200)
            .send({message: 'Usuario correctamente actualizado', userComplete, token})
        }else{
            res.status(404).send({message: 'Este usuario no existe en la Base de Datos, o verifique parametros'})
        }
    }catch(error){
        throw new Error(error);
    }
};

//Eliminar Usuario
const deleteUser = async(req, res) =>{
    try{
        const userId = req.params.id;
        const users = await user.findById(userId);

        if(!users){
            return res.status(404).json({error: "Usuario no encontrado"});
        }

        await user.remove();

    return res.json({message: "Usuario eliminado"})
    }catch(error){
        console.log(error);
        return res.status(500).json({error: "Error"});
    }
}

//Listar Usuarios
const readUser = async(req, res) =>{
    try{
        const usuario = await user.find();

        if(!usuario){
            res.status(400).send({
                message: 'No hay usuarios disponibles'
            })
        }else{
            res.status(200).json({"Usuarios encontrados": usuario});
        }
    }catch(error){
        throw new Error(error);
    }
};

//Iniciar sesión Login
const loginUser = async(req, res)=>{
    try {

        const {email, password} = req.body;
        let users = await user.findOne({email: email})

        if(!users) return  res.status(404).send({ok: false, message: 'No se encontro el email'});

        const correctParams = bcrypt.compareSync(password, users.password);

        if(!correctParams) return  res.status(400).send({ok: false, message: 'La contraseña es incorrecta.'})

        const token = await generateJWT(users._id, users.nombre, users.email);

        res.status(200).json({ok: true,'Usuario': users, token: token })

    } catch (error) {
        throw new Error(error);
    }
}

module.exports = {  CreateUser, 
                    updateUser,
                    deleteUser,
                    readUser,
                    loginUser}