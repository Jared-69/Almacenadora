'use strict'

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ToDoList = Schema({
    user: {
        type: Schema.Types.ObjectId, ref: 'User'
    },
    taskName: {
        type: String,
        require: true
    },
    description: {
        type: String,
        require: true
    },
    startDate: {
        type: Date,
        require: true
    },
    deadline: {
        type: Date,
        require: true
    },
    taskStatus: {
        type: String,
        require: true
    }
})

module.exports = mongoose.model('ToDoList', ToDoList)