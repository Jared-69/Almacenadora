'use strict'

const { Router } = require("express")
const { createToDo, 
        updateToDo,
        readToDo, 
        deleteToDo } = require("../controllers/todolist.controller");

const api = Router();

api.post("/create-tarea", createToDo);

api.put("/update-tarea/:id", updateToDo);

api.get("/read-tarea", readToDo);

api.delete("/delete-tarea/:id", deleteToDo);

module.exports = api;