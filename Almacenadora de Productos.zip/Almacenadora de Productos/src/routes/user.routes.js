'use strict'

const {Router} = require('express');
const { CreateUser, updateUser, deleteUser, readUser, loginUser} = require('../controllers/user.controller');
const {check} = require('express-validator');
const {validateJWT} = require('../middlewares/validate-jwt');

const api = Router();

api.post('/create-user', CreateUser);

api.put('/update-user/:id', validateJWT, updateUser);

api.delete('/delete-user/:id', deleteUser);

api.get('/read-user', readUser);

api.post('/login', loginUser);

module.exports = api;